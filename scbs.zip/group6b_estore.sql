-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 27, 2025 at 05:03 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `group6b_estore`
--

-- --------------------------------------------------------

--
-- Table structure for table `group6b_customers`
--

CREATE TABLE `group6b_customers` (
  `customer_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `group6b_customers`
--

INSERT INTO `group6b_customers` (`customer_id`, `first_name`, `last_name`, `email`, `phone`, `created_date`) VALUES
(1, 'Jzhirubeson', 'Yap', 'jzhiyap@gmail.com', '9054316156', '2025-02-11 05:12:13'),
(2, 'Prince RD', 'Parpa', 's2301994@usls.edu.ph', NULL, '2025-02-11 05:14:44'),
(3, 'Christian', 'Espinosa', 'c.espinosa@gmail.com', NULL, '2025-02-11 05:16:30');

-- --------------------------------------------------------

--
-- Table structure for table `group6b_orderitems`
--

CREATE TABLE `group6b_orderitems` (
  `order_item_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `group6b_orderitems`
--

INSERT INTO `group6b_orderitems` (`order_item_id`, `order_id`, `product_id`, `quantity`, `unit_price`) VALUES
(1, 1, 1, 1, 75000.00),
(2, 1, 2, 2, 3396.00),
(3, 2, 3, 3, 79999.00);

-- --------------------------------------------------------

--
-- Table structure for table `group6b_orders`
--

CREATE TABLE `group6b_orders` (
  `order_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(20) DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `group6b_orders`
--

INSERT INTO `group6b_orders` (`order_id`, `customer_id`, `order_date`, `status`) VALUES
(1, 1, '2025-02-11 05:23:06', 'pending'),
(2, 2, '2025-02-11 05:23:29', 'Shipped');

-- --------------------------------------------------------

--
-- Table structure for table `group6b_payments`
--

CREATE TABLE `group6b_payments` (
  `payment_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `payment_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `payment_amount` decimal(10,2) NOT NULL,
  `payment_method` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `group6b_payments`
--

INSERT INTO `group6b_payments` (`payment_id`, `order_id`, `payment_date`, `payment_amount`, `payment_method`) VALUES
(1, 1, '2025-02-11 05:28:11', 75000.00, 'Credit Card');

-- --------------------------------------------------------

--
-- Table structure for table `group6b_products`
--

CREATE TABLE `group6b_products` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock_quantity` int(11) DEFAULT 0,
  `stock_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `group6b_products`
--

INSERT INTO `group6b_products` (`product_id`, `product_name`, `product_description`, `price`, `stock_quantity`, `stock_date`) VALUES
(1, 'ROG Zephyrus G14', NULL, 75000.00, 10, '2024-11-11'),
(2, 'Logitech G435', NULL, 187.20, 25, '2024-11-11'),
(3, 'JBL PartyBox 710', NULL, 79999.00, 5, '2024-11-11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `group6b_customers`
--
ALTER TABLE `group6b_customers`
  ADD PRIMARY KEY (`customer_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `group6b_orderitems`
--
ALTER TABLE `group6b_orderitems`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `group6b_orders`
--
ALTER TABLE `group6b_orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `group6b_payments`
--
ALTER TABLE `group6b_payments`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `group6b_products`
--
ALTER TABLE `group6b_products`
  ADD PRIMARY KEY (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `group6b_customers`
--
ALTER TABLE `group6b_customers`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `group6b_orderitems`
--
ALTER TABLE `group6b_orderitems`
  MODIFY `order_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `group6b_orders`
--
ALTER TABLE `group6b_orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `group6b_payments`
--
ALTER TABLE `group6b_payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `group6b_products`
--
ALTER TABLE `group6b_products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `group6b_orderitems`
--
ALTER TABLE `group6b_orderitems`
  ADD CONSTRAINT `group6b_orderitems_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `group6b_orders` (`order_id`),
  ADD CONSTRAINT `group6b_orderitems_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `group6b_products` (`product_id`);

--
-- Constraints for table `group6b_orders`
--
ALTER TABLE `group6b_orders`
  ADD CONSTRAINT `group6b_orders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `group6b_customers` (`customer_id`);

--
-- Constraints for table `group6b_payments`
--
ALTER TABLE `group6b_payments`
  ADD CONSTRAINT `group6b_payments_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `group6b_orders` (`order_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
session_start();
 require 'connection.php';
 $sql = "SELECT tr_date, COUNT(*) AS date_count
 FROM transaction
 GROUP BY tr_date
 ORDER BY tr_date";
$result = mysqli_query($conn, $sql);

// Arrays to hold the labels (dates) and counts
$dates = [];
$dateCounts = [];

while ($row = mysqli_fetch_assoc($result)) {
$dates[] = $row['tr_date'];
$dateCounts[] = $row['date_count'];
}


?>
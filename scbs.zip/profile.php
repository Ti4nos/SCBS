<?php
    session_start();
    if (!isset($_SESSION['first_name'])) {
        header("Location: index.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SCBS Profile</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="styles.css">
    
    <style>
        /* bars */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        body {
            display: flex;
            height: 100%;
        }
        .sidebar {
            width: 200px;
            background-color: #2C3E50;
            color: white;
            display: flex;
            flex-direction: column;
            text-align: center;
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            transition: width 0.3s ease;
        }
        .sidebar.shrink {
            width: 60px;
        }
        .sidebar h2 {
            padding: 15px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .menu-item {
            padding: 15px;
            background-color: #D0DFE9;
            color: black;
            text-decoration: none;
            display: flex;
            align-items: center;
            border-bottom: 1px solid white;
            transition: padding 0.3s ease;
        }
        .menu-item i {
            margin-right: 10px;
        }
        .menu-item span {
            display: inline;
        }
        .sidebar.shrink .menu-item {
            text-align: center;
            
        }
        .sidebar.shrink .menu-item span {
            display: none;
        }
        .sidebar.shrink .menu-item i {
            display: block;

            font-size: 24px;
        }
        .menu-item:hover, .active {
            background-color: #5E7D8D;
            color: white;
        }
        .logout {
            margin-top: auto;
            background-color: #D0DFE9;
            text-align: center;
        }
        .main-content {
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            margin-left: 200px; /* Adjust for the width of the sidebar */
            transition: margin-left 0.3s ease;
        }
        .main-content.shrink {
            margin-left: 60px;
        }
        .topbar {
            width: calc(100% - 200px); /* Adjust for the width of the sidebar */
            height: 50px;
            background-color: #2C3E50;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
            color: white;
            position: fixed;
            top: 0;
            left: 200px; /* Adjust for the width of the sidebar */
            z-index: 1000;
            transition: left 0.3s ease, width 0.3s ease;
        }
        .topbar.shrink {
            left: 60px;
            width: calc(100% - 60px);
        }
        .content {
            flex-grow: 1;
            background-color: white;
            padding: 20px;
            margin-top: 50px; /* Adjust for the height of the topbar */
        }
        .user-icon {
            display: flex;
            align-items: center;
        }
        .user-icon span {
            margin-right: 10px;
        }
        .user-icon img {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background-color: #29A0B1;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        /* bars */
        .profile-card {
            display: flex;
            align-items: center;
            justify-content: space-around;
            width: 70%;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            background-color: #f9f9f9;
            margin: 20px auto;
        }
        
        .profile-image img {
            width: 200px;
            height: 200px;
            border-radius: 50%;
        }
        .profile-info {
            text-align: left;
            display: flex;
            flex-direction: column;
        }
        .bold {
            font-weight: bold;
        }
        .button-container {
            text-align: center;
            margin-top: 10px;
        }
        .change-password {
            padding: 10px;
            border: none;
            background-color: #2C3E50;
            color: white;
            cursor: pointer;
            border-radius: 5px;
        }
        .change-password:hover {
            background-color: #1A252F;
        }
        .qrimg{
            width: 200px;
        }
        .profile-info p{
            padding-bottom: 10px;
            display: flex;  
        }
        .change-info{
            padding: 10px;
            border: none;
            background-color: #2C3E50;
            color: white;
            cursor: pointer;
            border-radius: 5px; 
        }
        .change-info:hover {
            background-color: #1A252F;
        }
        .text-profile h1{
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 10px;
            border-bottom: 2px solid #2C3E50;
            padding-bottom: 5px;
        }
    </style>
    <script>
        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            const mainContent = document.querySelector('.main-content');
            const topbar = document.querySelector('.topbar');

            sidebar.classList.toggle('shrink');
            mainContent.classList.toggle('shrink');
            topbar.classList.toggle('shrink');
        }
    </script>
</head>
<body>
    <div class="sidebar">
        <h2>SCBS</h2>
        <a href="dashboard.php" class="menu-item"><i class="fas fa-tachometer-alt"></i> <span>DASHBOARD</span></a>
        <a href="transaction.php" class="menu-item"><i class="fas fa-exchange-alt"></i> <span>TRANSACTION</span></a>
        <a href="profile.php" class="menu-item active"><i class="fas fa-user"></i><span>PROFILE</span></a>
        <a href="about.php" class="menu-item"><i class="fas fa-info-circle"></i> <span>ABOUT</span></a>
        <a href="logout.php" class="menu-item logout"><i class="fas fa-sign-out-alt"></i> <span>LOG OUT</span></a>
    </div>
    <div class="main-content">
        <div class="topbar">
            <button onclick="toggleSidebar()">☰</button>
            <div class="user-icon">
                <span><?php echo htmlspecialchars($_SESSION['first_name']); ?></span>
                <img src="https://via.placeholder.com/30" alt="User Icon">
            </div>
        </div>
        <div class="content">
        <div class="text-profile">
                        <h1>User Profile</h1>
                    </div>
            <div class="profile-card">
                <div class="profile-image">
                    <img src="profileimage.png" alt="Profile Image">
                </div>
                <div class="profile-info">
                    <p><span class="bold">Full Name:</span> <?php echo htmlspecialchars($_SESSION['first_name'] ); ?></p>

                    <p><span class="bold">Date of Birth:</span> 05/20/2004</p>
                    <p><span class="bold">Age:</span> 20</p>
                    <p><span class="bold">Address:</span> Pahanoy City</p>
                    <p><span class="bold">Contact Number:</span> 09123452345</p>
                    <p><span class="bold">Email:</span> sample@gmail.com</p>
                    <p><span class="bold">Senior Citizen ID Number:</span> 049-241-234</p>
                </div>
                <img src="qrimage.png" class="qrimg" id="myBtn">
            </div>
            <!-- Trigger/Open The Modal -->


            <!-- The Modal -->
        <div id="myModal" class="modal">

            <!-- Modal content -->
            <div class="modal-content"> 
                    <div class="qr">
                    <span class="close">&times;</span>
                    <img src="qrimage.png" class="qr-img-modal">
                    </div>
                    <div class="text">
                        <p class="name">Jzhi Garces</p>
                        <p class="mobile">Mobile Number: 09123452345</p>
                        <p class="id-number">ID Number: 049-241-234</p>
                    </div>
            </div>
        </div>

            <div class="button-container">
                <button class="change-password">CHANGE PASSWORD</button>
                <button class="change-info">EDIT</button>
            </div>
        </div>
    </div>
    <script src="script.js"></script>
</body>
</html>
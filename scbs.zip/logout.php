<?php
session_start();

// Destroy the session and redirect to login page
session_unset(); // Unset all session variables
session_destroy(); // Destroy the session

header("Location: index.php"); // Redirect to login page
exit();
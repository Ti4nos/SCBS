<?php 
 session_start();
 require 'connection.php';
  
 $fname    = $_POST    ['first_name'];
 $password = $_POST    ['password'];
 
 $sql = "SELECT * FROM registration_info WHERE first_name = '$fname' AND password = '$password'";


 $result = $conn->query($sql);

 if($result)
 { 
    if($result->num_rows == 0)//empty
    {
        header("Location: index.php?verified=false");
    }
    else//result ok
    { 
         while($row = $result->fetch_assoc())
         {
          $_SESSION['first_name'] = $row['first_name'];
           header("Location: dashboard.php");
         }
    }
 }
?>
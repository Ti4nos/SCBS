<?php
  require_once 'connection.php';
  $action = isset($_GET['action'])? $_GET['action']: '';
  $id     = isset($_GET['id'    ])? $_GET['id'    ]: '';
  switch($action)
  {
    case 'approve'        : approveClient($conn, $id);    
    break;
    case 'decline'        : declineClient($conn, $id);    
    break;
    case 'insertClient': insertClient($conn, $_POST);    
    break;
    default: '';
  }
  
  function insertClient($conn, $data)
  {
    //$name             = $data['Name'     ]; if mayara single qoutation ang input ma error
    // //$email            = $data['Email' ];
    // $birthday         = $data['Birthday'     ];
    // $age              = $data['Age'     ];
    // $contact          = $data['Contact'     ];
    // $address          = $data['Address'     ];

    $fname               = mysqli_real_escape_string($conn,$data['first_name'  ]);
    $lname               = mysqli_real_escape_string($conn,$data['last_name'   ]);
    $suffix              = mysqli_real_escape_string($conn,$data['suffix'      ]);
    $birthday            = mysqli_real_escape_string($conn,$data['birthday'    ]);
    $address             = mysqli_real_escape_string($conn,$data['address'     ]);
    $contact             = mysqli_real_escape_string($conn,$data['contact'     ]);
    $email               = mysqli_real_escape_string($conn,$data['email'       ]);
    $password            = mysqli_real_escape_string($conn,$data['password'    ]);

    $sql              = "INSERT INTO registration_info (first_name, last_name, suffix, birthday, address, contact, email, password) VALUES 
                        ('$fname', '$lname', '$suffix','$birthday','$address','$contact','$email','$password')";
                        
    $result           = $conn->query($sql);
    header("Location:index.php");
  }
  
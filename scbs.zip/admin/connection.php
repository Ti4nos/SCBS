<?php
$servername = "localhost:3306";
$username   = "s2302172_group_6";
$password   = "Spiderweb123";
 $database   = "s2302172_group6"; //create database first
// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";
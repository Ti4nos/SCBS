<?php 
session_start();

$verified = isset($_GET['verified']) ? $_GET['verified'] : '';
if (isset($_SESSION['first_name'])) {
    header("Location:dashboard.php");
}
?>
<html>
<head>
    <title>Senior Citizen Booklet System</title>
    <style>
        body, html {
            height: 100%;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            background-image: url(senior.jpg);
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
            
        }
        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(47, 65, 86, 0.7);
            z-index: -1;
        }
        .container {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100%;
            position: absolute;
            
        }
        .card {
            background-color: #c8d9e6;
            padding: 40px 60px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            width: 350px;
            display: flex;
            flex-direction: column;
        }
        h1 {
            text-align: left;
            margin-bottom: 10px;
            font-size: 2rem;
            font-weight: bold;
            color: #0a0a23;
        }
        p {
            text-align: center;
            margin-bottom: 20px;
            font-size: 1.2rem;
            font-weight: bold;
            color: #0a0a23;
        }
        label {
            font-size: 1rem;
            margin-bottom: 5px;
            color: #0a0a23;
        }
        input {
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #333;
            border-radius: 5px;
            width: 100%;
        }
        button {
            padding: 10px;
            background-color: #0a0a23;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
        }
        a {
            text-align: left;
            margin-top: 10px;
            color: #0a0a23;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        /* The Modal (background) */
        .modal {
            display: none; /* Hidden by default */
            position: fixed; /* Stay in place */
            z-index: 1; /* Sit on top */
            padding-top: 70px; /* Location of the box */
            left: 0;
            top: 0;
            width: 100%; /* Full width */
            height: 100%; /* Full height */
            overflow: auto; /* Enable scroll if needed */
            background-color: rgb(0,0,0); /* Fallback color */
            background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
            }

            /* Modal Content */
        .modal-content {
            background-color: #fefefe;
            margin: auto;
            padding: 20px;
            border: 1px solid #888;
            width: 30%;
            }
        .modal-content p{
            text-align: left;
        }

            /* The Close Button */
        .close {
            color: #aaaaaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            }

        .close:hover,
        .close:focus {
            color: #000;
            text-decoration: none;
            cursor: pointer;
            }
        .modal-content .name{
            display: flex;
        }

    </style>
</head>
<body>
    <div class="container">

            <!-- The Modal -->
            <div id="myModal" class="modal">

            <!-- Modal content -->
            <div class="modal-content">
                <form method="POST" action="register.process.php?action=insertClient">
                    <span class="close">&times;</span>
                    <p>Name</p>
                    <div class="name">
                        <input type="text" placeholder="First" name="first_name" required>
                        <input style="margin-left:2px ; margin-right: 2px" type="text" placeholder="Last" name="last_name" required>
                        <input type="text" placeholder="Suffix" name="suffix">
                    </div>

                    <p>Birthday</p>
                    <input type="date" placeholder="Birthday" name="birthday" required>
                    <p>Address</p>
                    <input type="text" placeholder="Address" name="address" required>
                    <p>Contact No.</p>
                    <input type="number" placeholder="Contact" name="contact" required>
                    <p>Email</p>
                    <input type="email" placeholder="Email" name="email">
                    <p>Password</p>
                    <input type="password" placeholder="Password" name="password" required>
                    <button type="submit">Submit</button>
                </form>
            </div>

        </div>
        <div class="card">
            <form method="POST" action="login.process.php">
                <h1>Log In</h1>
                <p>Welcome To SCBS</p>
                <label>First Name:</label>
                <input type="text" id="username" placeholder="Sample" name="first_name" required>

                <label>Password:</label>
                <input type="password" id="password" placeholder="Password" name="password" required>
                <button>Log in</button>

                <a href="#">Forgot Password?</a>
                <p>Need a SCBS account? <a href="#" id="myBtn">Create Account</a></p>
            </form>
        </div>
    </div>
    <script>
        // Get the modal
        var modal = document.getElementById("myModal");

        // Get the button that opens the modal
        var btn = document.getElementById("myBtn");

        // Get the <span> element that closes the modal
        var span = document.getElementsByClassName("close")[0];

        // When the user clicks the button, open the modal 
        btn.onclick = function() {
        modal.style.display = "block";
        }

        // When the user clicks on <span> (x), close the modal
        span.onclick = function() {
        modal.style.display = "none";
        }

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
            }
        }
    </script>
</body>
</html>